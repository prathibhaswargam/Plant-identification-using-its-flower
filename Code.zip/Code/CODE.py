import os
import numpy as np
import cv2
import matplotlib.pyplot as plt

labels = ['hibiscus', 'jasmine', 'rose']
img_size = 200
data = []

def get_training_data(data_dir):
    for label in labels:
        path = os.path.join(data_dir, label)
        class_num = labels.index(label)
        for img in os.listdir(path):
            try:
                img_arr = cv2.imread(os.path.join(path, img), cv2.IMREAD_COLOR)
                resized_arr = cv2.resize(img_arr, (img_size, img_size))
                data.append([resized_arr, class_num])
            except Exception as e:
                print(e)
    return np.array(data)

train = get_training_data("C:/Users/prath/OneDrive/Desktop/flowers")

x = []
y = []
z = []
count = 0

for i in range(len(train)):
    if train[i][1] == 0:
        x.append(train[i][0:2])
    elif train[i][1] == 1:
        y.append(train[i][0:2])
        count = count + 1
    else:
        z.append(train[i][0:2])

print(count)

xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.25, random_state=47)

d = np.array(xtrain).reshape(750, 120000)
e = np.array(xtest).reshape(250, 120000)

sc_x = StandardScaler()
d = sc_x.fit_transform(d)
e = sc_x.transform(e)

model = LogisticRegression(random_state=0, max_iter=1000)
model.fit(d, ytrain)

y_pred = model.predict(e)

print("Confusion matrix:\n", confusion_matrix(ytest, y_pred))
print("Accuracy:", accuracy_score(ytest, y_pred))