import os
import numpy as np
import cv2
import matplotlib.pyplot as plt
labels = ['hibiscus','jasmine','rose']
img_size = 200
data = []
def get_training_data(data_dir):
  for label in labels:
    path=os.path.join (data_dir, label)
    class_num = labels.index(label)
    print(class_num)
    for img in os.listdir (path):
    
      try:
        
        img_arr = cv2.imread(os.path. join (path, img), cv2.COLOR_BAYER_GB2RGB)
        print(img_arr.shape)
        resized_arr = cv2.resize(img_arr, (img_size, img_size))
        #print(resized_arr)
        data.append ([resized_arr, class_num])
      except Exception as e:
        print(e)
    
  return np.array(data)


train = get_training_data("C:/Users/prath/OneDrive/Desktop/flowers")
print(data)
for i in range(0,10):
  plt.imshow(data[i][0])
  print(data[i][0])
  
for label in labels:
  print(labels.index(label))
x=[]
y=[]
z=[]
count=0
for i in range(len(train)):
  if train[i][1]==0:
    x.append(train[i][0:2])
  elif train[i][1]==0:
    y.append(train[i][0:2])
    count=count+1
  else:
    z.append(train[i][0:2])
print(count)
x
y
z

x=[]
y=[]
for i,j in data:
  x.append(i)
  y.append(j)
x
y
